export class Seller {
    sellerID!:number;
    productBiddingdate!:Date;
    productCategory!:String;
    productDescription!:String;
    productID!:number;
    productName!:String;
    productPrice!:Number;
    productStartamt!:number;
    sellerAddress!:String;
    sellerEmail!:string;
    sellerName!:string;
    sellerNumber!:number;
}

